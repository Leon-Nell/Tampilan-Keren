# Termux-Banner-Bash Shell

<p align="center">
     Trim Dir | Prompt username | termux extra kyeboard |
     popups key | new session open with hot key | swich between session with hot key
</p>

## Preview Screenshot

<p align="center">
  <img src="logo.jpg" width="200" hight="220">
</p>

## Preview of setup 

<p align="center">
<img src="setup.jpg" width="200" hight="220">
</p>

## setup instuction

```
git clone 

```
